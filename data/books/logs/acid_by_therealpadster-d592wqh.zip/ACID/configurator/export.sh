#!/bin/bash

cp -r "$HOME/.themes/ACID" "$HOME/.themes/ACID-$exportname"
